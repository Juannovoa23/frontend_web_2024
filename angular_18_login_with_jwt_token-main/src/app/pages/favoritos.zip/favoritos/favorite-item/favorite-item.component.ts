import { Component } from '@angular/core';

@Component({
  selector: 'app-favorite-item',
  standalone: true,
  imports: [],
  templateUrl: './favorite-item.component.html',
  styleUrl: './favorite-item.component.css'
})
export class FavoriteItemComponent {

}
