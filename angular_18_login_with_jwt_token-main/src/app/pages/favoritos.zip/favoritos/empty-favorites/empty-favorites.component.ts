import { Component } from '@angular/core';

@Component({
  selector: 'app-empty-favorites',
  templateUrl: './empty-favorites.component.html',
  styleUrls: ['./empty-favorites.component.css']
})
export class EmptyFavoritesComponent {}
