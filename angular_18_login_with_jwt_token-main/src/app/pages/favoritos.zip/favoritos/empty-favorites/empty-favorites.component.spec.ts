import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmptyFavoritesComponent } from './empty-favorites.component';

describe('EmptyFavoritesComponent', () => {
  let component: EmptyFavoritesComponent;
  let fixture: ComponentFixture<EmptyFavoritesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EmptyFavoritesComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EmptyFavoritesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
